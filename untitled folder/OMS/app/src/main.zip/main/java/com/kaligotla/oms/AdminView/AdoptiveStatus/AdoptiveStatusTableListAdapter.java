package com.kaligotla.oms.AdminView.AdoptiveStatus;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.kaligotla.oms.R;

import java.util.List;

public class AdoptiveStatusTableListAdapter extends RecyclerView.Adapter<AdoptiveStatusTableListAdapter.MyViewHolder> {

    Context context;
    List<AdoptiveStatus> adoptiveStatusList;

    public AdoptiveStatusTableListAdapter(Context context, List<AdoptiveStatus> adoptiveStatusList) {
        this.context = context;
        this.adoptiveStatusList = adoptiveStatusList;
    }

    @NonNull
    @Override
    public AdoptiveStatusTableListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from( context ).inflate( R.layout.activity_adoptive_status_table_list_adapter, null );
        return new AdoptiveStatusTableListAdapter.MyViewHolder( view );
    }

    @Override
    public void onBindViewHolder(@NonNull AdoptiveStatusTableListAdapter.MyViewHolder holder, int position) {
        Log.e("ID",""+adoptiveStatusList.get(position).getId());
        holder.id.setText(""+adoptiveStatusList.get(position).getId());
        holder.status.setText(adoptiveStatusList.get(position).getStatus());
    }

    @Override
    public int getItemCount() {
        return adoptiveStatusList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView id, status;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            id = itemView.findViewById( R.id.id);
            status = itemView.findViewById( R.id.status);

            itemView.setOnClickListener( this );
        }

        @Override
        public void onClick(View v) {
            int aid = adoptiveStatusList.get(getAdapterPosition()).getId();
            Log.e("Clicked position",""+adoptiveStatusList.get(getAdapterPosition()).getId());
            context.startActivity(new Intent(context, AdoptiveStatusTableDetails.class)
                    .putExtra("aid",aid));
        }
    }
}