package com.kaligotla.oms.AdminView.Admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.kaligotla.oms.Essentials.Constants;
import com.kaligotla.oms.Essentials.CustomDateFormate;
import com.kaligotla.oms.AdminView.Location.Location;
import com.kaligotla.oms.Login;
import com.kaligotla.oms.MainActivity;
import com.kaligotla.oms.OrphanageActivities.AddOrphanageActivities;
import com.kaligotla.oms.R;
import com.kaligotla.oms.AdminView.Role.Role;
import com.kaligotla.oms.orphanage.Orphanage;
import com.kaligotla.oms.Essentials.DBService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AdminTableDetails extends AppCompatActivity {

    int aid;
    EditText name, dob, gender, govt_id_type, govt_id, mobile, email, password, address, location, role, orphanage;
    pl.droidsonroids.gif.GifImageView image;
    Toolbar sponsor_toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_admin_table_details );
        sponsor_toolbar = findViewById( R.id.sponsor_toolbar );
        name = findViewById( R.id.name);
        dob = findViewById( R.id.dob);
        gender = findViewById( R.id.gender);
        govt_id_type = findViewById( R.id.govt_id_type);
        govt_id = findViewById( R.id.govt_id);
        mobile = findViewById( R.id.mobile);
        email = findViewById( R.id.email);
        password = findViewById( R.id.password);
        address = findViewById( R.id.address);
        location = findViewById( R.id.location);
        role = findViewById( R.id.role);
        orphanage = findViewById( R.id.orphanage);
        aid = getIntent().getIntExtra("aid",0);
        getAdmin(aid);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setSupportActionBar( sponsor_toolbar );
        getSupportActionBar().setDisplayHomeAsUpEnabled( true );
    }

    private void getAdmin(int aid) {
        Log.e("inside getAdmin",""+aid);
        new Retrofit.Builder()
                .addConverterFactory( GsonConverterFactory.create())
                .baseUrl( Constants.BASE_URL)
                .build()
                .create( DBService.class)
                .getAdminByID(aid)
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                        Location l = new Location();
                        Role r = new Role();
                        Orphanage o = new Orphanage();
                        JsonArray array = response.body().get("data").getAsJsonArray();
                        if(array.size()>0){
                            JsonObject jsonObject = array.get(0).getAsJsonObject();
                            Log.e("jsonObject",""+jsonObject);

                            name.setText(jsonObject.get( "name" ).getAsString());
                            if(!jsonObject.get( "dob" ).isJsonNull())
                                dob.setText( CustomDateFormate.convert( jsonObject.get( "dob" ).toString() ) );
                            else dob.setText(null);
                            if(!jsonObject.get( "gender" ).isJsonNull())
                                gender.setText( jsonObject.get( "gender" ).getAsString() );
                            else gender.setText(null);
                            if(!jsonObject.get( "govt_id_type" ).isJsonNull())
                                govt_id_type.setText( jsonObject.get( "govt_id_type" ).getAsString() );
                            else govt_id_type.setText(null);
                            if(!jsonObject.get( "govt_id" ).isJsonNull())
                                govt_id.setText( jsonObject.get( "govt_id" ).getAsString() );
                            else govt_id.setText(null);
                            if(!jsonObject.get( "mobile" ).isJsonNull())
                                mobile.setText( jsonObject.get( "mobile" ).getAsString() );
                            else mobile.setText(null);
                            email.setText(jsonObject.get( "email" ).getAsString());
                            password.setText(jsonObject.get( "password" ).getAsString());
                            if(!jsonObject.get( "address" ).isJsonNull())
                                address.setText( jsonObject.get( "address" ).getAsString() );
                            else address.setText(null);
                            if(!jsonObject.get( "location_id" ).isJsonNull()) {
                                l.setId( jsonObject.get( "location_id" ).getAsInt() );
                                if(!jsonObject.get( "pincode" ).isJsonNull()){
                                    l.setPincode( jsonObject.get( "pincode" ).getAsInt());
                                } else l.setPincode( 0 );
                                if(!jsonObject.get( "area" ).isJsonNull()){
                                    l.setArea( jsonObject.get( "area" ).toString());
                                } else l.setArea( null );
                                if(!jsonObject.get( "city" ).isJsonNull()){
                                    l.setCity( jsonObject.get( "city" ).getAsString());
                                } else l.setCity( null );
                                if(!jsonObject.get( "district" ).isJsonNull()){
                                    l.setDistrict( jsonObject.get( "district" ).getAsString());
                                } else l.setDistrict( null );
                                if(!jsonObject.get( "state" ).isJsonNull()){
                                    l.setState( jsonObject.get( "state" ).getAsString());
                                } else l.setState( null );
                                location.setText( l.toString() );
                            } else {
                                location.setText(null);
                            }
                            if(!jsonObject.get( "role" ).isJsonNull()) {
                                r.setRole( jsonObject.get( "role" ).toString() );
                                role.setText( r.getRole() );
                            } else {
                                location.setText(null);
                            }
                            if(!jsonObject.get( "orphanage_id" ).isJsonNull()) {
                                o.setId( jsonObject.get( "orphanage_id" ).getAsInt() );
                                if(!jsonObject.get( "type" ).isJsonNull()){
                                    o.setType( jsonObject.get( "type" ).toString());
                                } else o.setType( null );
                                if(!jsonObject.get( "address" ).isJsonNull()){
                                    o.setAddress( jsonObject.get( "address" ).toString());
                                } else o.setAddress( null );
                                if(!jsonObject.get( "contact_person" ).isJsonNull()){
                                    o.setContact_person( jsonObject.get( "contact_person" ).toString());
                                } else o.setContact_person( null );
                                if(!jsonObject.get( "mobile" ).isJsonNull()){
                                    o.setMobile( jsonObject.get( "mobile" ).toString());
                                } else o.setMobile( null );
                                if(!jsonObject.get( "phone" ).isJsonNull()){
                                    o.setPhone( jsonObject.get( "phone" ).toString());
                                } else o.setPhone( null );
                                if(!jsonObject.get( "email" ).isJsonNull()){
                                    o.setEmail( jsonObject.get( "email" ).toString());
                                } else o.setEmail( null );
                                if(!jsonObject.get( "in_home" ).isJsonNull()){
                                    o.setIn_home( jsonObject.get( "in_home" ).getAsInt());
                                } else o.setIn_home( 0 );
                                if(!jsonObject.get( "adoptable" ).isJsonNull()){
                                    o.setAdoptable( jsonObject.get( "adoptable" ).getAsInt());
                                } else o.setAdoptable( 0 );
                                if(!jsonObject.get( "boys" ).isJsonNull()){
                                    o.setBoys( jsonObject.get( "boys" ).getAsInt());
                                } else o.setBoys( 0 );
                                if(!jsonObject.get( "girls" ).isJsonNull()){
                                    o.setGirls( jsonObject.get( "girls" ).getAsInt());
                                } else o.setGirls( 0 );

                                orphanage.setText(o.toString());

                            } else {
                                orphanage.setText(null);
                            }
                        }
                    }
                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                    }
                });
    }

    public void cancel(View view) {
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.sponsor_menu, menu );
        menu.removeItem( R.id.login );
        menu.removeItem( R.id.Home );
        menu.removeItem( R.id.donate );
        menu.removeItem( R.id.adopt );
        return super.onCreateOptionsMenu( menu );
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            item.setIcon( R.drawable.back );
            item.setVisible( true );
            finish();
        } else if (item.getTitle().equals( "Home" )) {
            setIntent( new Intent( AdminTableDetails.this, MainActivity.class ) );
        } else if (item.getTitle().equals( "Logout" )) {
            Toast.makeText( this, "Logout", Toast.LENGTH_SHORT ).show();
            SharedPreferences preferences = getSharedPreferences( "store", MODE_PRIVATE );
            preferences.edit().putBoolean( "login_status", false ).commit();
            startActivity( new Intent( AdminTableDetails.this, Login.class ) );
        } else if (item.getTitle().equals("Add")) {
            startActivity( new Intent( this, AddOrphanageActivities.class ) );
        } else {
            finish();
            finish();
            finish();
        }
        return super.onOptionsItemSelected( item );
    }

}