package com.kaligotla.oms.OrphanageActivities;

import com.kaligotla.oms.orphanage.Orphanage;

public class OrphanageActivities {
    private int id;

    private Orphanage orphanage;

    private String details, images;

    public OrphanageActivities() {
    }

    public OrphanageActivities(Orphanage orphanage, String details, String images) {
        this.orphanage = orphanage;
        this.details = details;
        this.images = images;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Orphanage getOrphanage() {
        return orphanage;
    }

    public void setOrphanage(Orphanage orphanage) {
        this.orphanage = orphanage;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    @Override
    public String toString() {
        return "OrphanageActivities{" +
                "id=" + id +
                ", orphanage=" + orphanage +
                ", details='" + details + '\'' +
                ", images='" + images + '\'' +
                '}';
    }
}
