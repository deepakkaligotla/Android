package com.kaligotla.oms;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {
    Toolbar sponsor_toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        sponsor_toolbar = findViewById( R.id.sponsor_toolbar );
    }

    @Override
    protected void onResume() {
        setSupportActionBar( sponsor_toolbar );
        getSupportActionBar().setDisplayHomeAsUpEnabled( false );
        super.onResume();
    }

    public void Donate(View view) {
        startActivity( new Intent( MainActivity.this, Register.class ) );
    }

    public void Adopt(View view) {
        startActivity( new Intent( MainActivity.this, Register.class ) );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.sponsor_menu, menu );
        menu.removeItem( R.id.Logout );
        menu.removeItem( R.id.adopt );
        menu.removeItem( R.id.donate );
        return super.onCreateOptionsMenu( menu );
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getTitle().equals( "Login" )) {
            startActivity( new Intent( MainActivity.this, Login.class ) );
            finish();
        } else if (item.getTitle().equals( "Home" )) {
            setIntent( new Intent( MainActivity.this, MainActivity.class ) );
        } else if (item.getTitle().equals( "Logout" )) {
            Toast.makeText( this, "Logout", Toast.LENGTH_SHORT ).show();
            SharedPreferences preferences = getSharedPreferences( "store", MODE_PRIVATE );
            preferences.edit().putInt( "sid", 0 ).commit();
            preferences.edit().putBoolean( "login_status", false ).commit();
            startActivity( new Intent( MainActivity.this, Login.class ) );
            finish();
        } else {
            finish();
            finish();
            finish();
        }
        return super.onOptionsItemSelected( item );
    }
}