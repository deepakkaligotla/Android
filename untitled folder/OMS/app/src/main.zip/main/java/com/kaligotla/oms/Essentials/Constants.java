package com.kaligotla.oms.Essentials;

public class Constants {
    public static final String BASE_URL = "http://54.238.252.168:4000/";
}
