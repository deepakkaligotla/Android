package com.kaligotla.oms.Essentials;

import com.google.gson.JsonObject;
import com.kaligotla.oms.Cred;
import com.kaligotla.oms.SponsorView.Sponsor;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface DBService {

    @POST("newsponsor")
    public Call<JsonObject> register(@Body Sponsor sponsor);

    @POST("sponsorlogin")
    public Call<JsonObject> sponsorlogin(@Body Cred cred);

    @POST("adminlogin")
    public Call<JsonObject> adminlogin(@Body Cred cred);

    @GET("")
    public Call<JsonObject> activities();

    @GET("sponsors")
    public Call<JsonObject> sponsors();

    @GET("findByIdSponsor/{id}")
    public Call<JsonObject> getSponsorByID(@Path("id") int id);

    @GET("admins")
    public Call<JsonObject> admins();

    @GET("childs")
    public Call<JsonObject> childs();

    @GET("roles")
    public Call<JsonObject> roles();

    @GET("orphanages")
    public Call<JsonObject> orphanages();

    @GET("adoptstatus")
    public Call<JsonObject> adoptstatus();

    @GET("findByIdAdmin/{id}")
    public Call<JsonObject> getAdminByID(@Path("id") int id);

    @GET("findByIdRole/{id}")
    public Call<JsonObject> getRoleByID(@Path("id") int id);

    @GET("findByIdChild/{id}")
    public Call<JsonObject> getChildByID(@Path("id") int id);

    @GET("findByIdOrphanage/{id}")
    public Call<JsonObject> getOrphanageByID(@Path("id") int id);

    @GET("findByIdAdoptStatus/{id}")
    public Call<JsonObject> getAdoptStatusByID(@Path("id") int id);

}
