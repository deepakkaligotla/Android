package com.kaligotla.oms.AdminView.Child;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.kaligotla.oms.Essentials.Constants;
import com.kaligotla.oms.Essentials.CustomDateFormate;
import com.kaligotla.oms.AdminView.Location.Location;
import com.kaligotla.oms.Login;
import com.kaligotla.oms.MainActivity;
import com.kaligotla.oms.OrphanageActivities.AddOrphanageActivities;
import com.kaligotla.oms.R;
import com.kaligotla.oms.AdminView.Role.Role;
import com.kaligotla.oms.orphanage.Orphanage;
import com.kaligotla.oms.Essentials.DBService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ChildsTableDetails extends AppCompatActivity {

    int aid;
    EditText name, dob, gender, admitted_date, leave_date, mother_name, father_name, mobile, status_id, admin_id;
    pl.droidsonroids.gif.GifImageView image;
    Toolbar sponsor_toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_childs_table_details );
        sponsor_toolbar = findViewById( R.id.sponsor_toolbar );
        name = findViewById( R.id.name);
        dob = findViewById( R.id.dob);
        gender = findViewById( R.id.gender);
        admitted_date = findViewById( R.id.admitted_date );
        leave_date = findViewById( R.id.leave_date );
        mother_name = findViewById( R.id.mother_name );
        father_name = findViewById( R.id.father_name );
        mobile = findViewById( R.id.mobile);
        status_id = findViewById( R.id.status_id );
        admin_id = findViewById( R.id.admin_id );
        aid = getIntent().getIntExtra("aid",0);
        getAdmin(aid);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setSupportActionBar( sponsor_toolbar );
        getSupportActionBar().setDisplayHomeAsUpEnabled( true );
    }

    private void getAdmin(int aid) {
        Log.e("inside getAdmin",""+aid);
        new Retrofit.Builder()
                .addConverterFactory( GsonConverterFactory.create())
                .baseUrl( Constants.BASE_URL)
                .build()
                .create( DBService.class)
                .getChildByID(aid)
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                        Location l = new Location();
                        Role r = new Role();
                        Orphanage o = new Orphanage();
                        JsonArray array = response.body().get("data").getAsJsonArray();
                        if(array.size()>0){
                            JsonObject jsonObject = array.get(0).getAsJsonObject();
                            Log.e("jsonObject",""+jsonObject);
                            if(!jsonObject.get( "child_name" ).isJsonNull())
                                name.setText(jsonObject.get( "child_name" ).getAsString());
                            else name.setText(null);
                            if(!jsonObject.get( "child_dob" ).isJsonNull())
                                dob.setText( CustomDateFormate.convert( jsonObject.get( "dob" ).toString() ) );
                            else dob.setText(null);
                            if(!jsonObject.get( "child_gender" ).isJsonNull())
                                gender.setText( jsonObject.get( "child_gender" ).getAsString() );
                            else gender.setText(null);
                            if(!jsonObject.get( "admitted_date" ).isJsonNull())
                                admitted_date.setText( CustomDateFormate.convert( jsonObject.get( "admitted_date" ).getAsString() ) );
                            else admitted_date.setText(null);
                            if(!jsonObject.get( "leave_date" ).isJsonNull())
                                leave_date.setText( CustomDateFormate.convert( jsonObject.get( "leave_date" ).getAsString() ) );
                            else leave_date.setText(null);
                            if(!jsonObject.get( "mother_name" ).isJsonNull())
                                mother_name.setText( jsonObject.get( "mother_name" ).getAsString() );
                            else mother_name.setText(null);
                            if(!jsonObject.get( "father_name" ).isJsonNull())
                                father_name.setText( jsonObject.get( "father_name" ).getAsString() );
                            else father_name.setText(null);
                            if(!jsonObject.get( "mobile" ).isJsonNull())
                                mobile.setText( jsonObject.get( "mobile" ).getAsString() );
                            else mobile.setText(null);
                            if(!jsonObject.get( "status_id" ).isJsonNull())
                                status_id.setText( jsonObject.get( "status_id" ).getAsString() );
                            else status_id.setText(null);
                            if(!jsonObject.get( "admin_id" ).isJsonNull())
                                admin_id.setText( jsonObject.get( "admin_id" ).getAsString() );
                            else admin_id.setText(null);
                        }
                    }
                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                    }
                });
    }

    public void cancel(View view) {
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.sponsor_menu, menu );
        menu.removeItem( R.id.login );
        menu.removeItem( R.id.Home );
        menu.removeItem( R.id.donate );
        menu.removeItem( R.id.adopt );
        return super.onCreateOptionsMenu( menu );
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            item.setIcon( R.drawable.back );
            item.setVisible( true );
            finish();
        } else if (item.getTitle().equals( "Home" )) {
            setIntent( new Intent( ChildsTableDetails.this, MainActivity.class ) );
        } else if (item.getTitle().equals( "Logout" )) {
            Toast.makeText( this, "Logout", Toast.LENGTH_SHORT ).show();
            SharedPreferences preferences = getSharedPreferences( "store", MODE_PRIVATE );
            preferences.edit().putBoolean( "login_status", false ).commit();
            startActivity( new Intent( ChildsTableDetails.this, Login.class ) );
        } else if (item.getTitle().equals("Add")) {
            startActivity( new Intent( this, AddOrphanageActivities.class ) );
        } else {
            finish();
            finish();
            finish();
        }
        return super.onOptionsItemSelected( item );
    }
}