package com.kaligotla.oms.SponsorView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.kaligotla.oms.Essentials.Constants;
import com.kaligotla.oms.Essentials.DBService;
import com.kaligotla.oms.Login;
import com.kaligotla.oms.R;
import com.kaligotla.oms.OrphanageActivities.AddOrphanageActivities;

import pl.droidsonroids.gif.GifImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class SponsorHome extends AppCompatActivity {
    Toolbar sponsor_toolbar;
    GifImageView kids_jumping;
    RecyclerView OrphanageActivitiesRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_sponsor_home );
        sponsor_toolbar = findViewById( R.id.sponsor_toolbar );
        kids_jumping = findViewById( R.id.kids_jumping );
        OrphanageActivitiesRecyclerView = findViewById( R.id.OrphanageActivitiesRecyclerView );
    }

    @Override
    protected void onResume() {
        setSupportActionBar( sponsor_toolbar );
        getSupportActionBar().setDisplayHomeAsUpEnabled( true );
        kids_jumping.animate();
        super.onResume();
    }

    public void orphanageActivities() {
        new Retrofit.Builder()
                .addConverterFactory( GsonConverterFactory.create() )
                .baseUrl( Constants.BASE_URL )
                .build()
                .create( DBService.class )
                .activities(  )
                .enqueue( new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                        JsonArray jsonArray = response.body().getAsJsonArray( "data" );
                        JsonObject jsonObject;
                        if (jsonArray.size() > 0) {
                            jsonObject = jsonArray.get( 0 ).getAsJsonObject();
                            int aid = jsonObject.get( "id" ).getAsInt();
                            int oid = jsonObject.get( "orphanage_id" ).getAsInt();
                            String activityDetails = jsonObject.get( "details" ).getAsString();
                            String activityImages = jsonObject.get( "images" ).getAsString();
                            finish();
                        }
                        else if(jsonArray.size()==0)
                            Toast.makeText( SponsorHome.this, "Got Orphanage Activities from DB", Toast.LENGTH_SHORT ).show();
                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        Toast.makeText( SponsorHome.this, "Failed to get Orphanage Activites", Toast.LENGTH_SHORT ).show();
                    }
                } );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.sponsor_menu, menu );
        menu.removeItem( R.id.login );
        menu.removeItem( R.id.Home );
        return super.onCreateOptionsMenu( menu );
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            item.setIcon( R.drawable.back );
            finish();
        } else if (item.getTitle().equals( "Donate" )) {
            startActivity( new Intent( SponsorHome.this, Donate.class ) );
        } else if (item.getTitle().equals( "Adopt" )) {
            startActivity( new Intent( SponsorHome.this, Adopt.class ) );
        } else if (item.getTitle().equals( "Logout" )) {
            Toast.makeText( this, "Logout", Toast.LENGTH_SHORT ).show();
            SharedPreferences preferences = getSharedPreferences( "store", MODE_PRIVATE );
            preferences.edit().putBoolean( "sponsor_logged_in", false ).commit();
            startActivity( new Intent( SponsorHome.this, Login.class ) );
        } else if (item.getTitle().equals("Add"))
            startActivity(new Intent(this, AddOrphanageActivities.class));
        else {
            finish();
            finish();
            finish();
        }
        return super.onOptionsItemSelected( item );
    }
}