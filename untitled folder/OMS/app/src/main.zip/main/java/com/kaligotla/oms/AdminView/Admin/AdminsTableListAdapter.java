package com.kaligotla.oms.AdminView.Admin;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.kaligotla.oms.R;

import java.util.List;

public class AdminsTableListAdapter extends RecyclerView.Adapter<AdminsTableListAdapter.MyViewHolder> {

    Context context;
    List<Admin> adminList;

    public AdminsTableListAdapter(Context context, List<Admin> adminList) {
        this.context = context;
        this.adminList = adminList;
    }

    @NonNull
    @Override
    public AdminsTableListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from( context ).inflate( R.layout.activity_admins_table_list_adapter, null );
        return new AdminsTableListAdapter.MyViewHolder( view );
    }

    @Override
    public void onBindViewHolder(@NonNull AdminsTableListAdapter.MyViewHolder holder, int position) {
        Log.e("ID",""+adminList.get(position).getId());
        holder.id.setText(""+adminList.get(position).getId());
        holder.name.setText(adminList.get(position).getName());
        holder.mobile.setText(adminList.get(position).getMobile());
        holder.email.setText(adminList.get(position).getEmail());
    }

    @Override
    public int getItemCount() {
        return adminList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView id, name, mobile, email;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            id = itemView.findViewById( R.id.id);
            name = itemView.findViewById( R.id.name);
            mobile = itemView.findViewById( R.id.mobile );
            email = itemView.findViewById( R.id.email );

            itemView.setOnClickListener( this );
        }

        @Override
        public void onClick(View v) {
            int aid = adminList.get(getAdapterPosition()).getId();
            Log.e("Clicked position",""+adminList.get(getAdapterPosition()).getId());
            context.startActivity(new Intent(context, AdminTableDetails.class)
                    .putExtra("aid",aid));
        }
    }
}