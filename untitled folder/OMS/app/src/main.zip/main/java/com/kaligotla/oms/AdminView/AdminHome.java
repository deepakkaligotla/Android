package com.kaligotla.oms.AdminView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.kaligotla.oms.AdminView.Admin.AdminsTable;
import com.kaligotla.oms.AdminView.AdoptiveStatus.AdoptiveStatusTable;
import com.kaligotla.oms.AdminView.Child.ChildsTable;
import com.kaligotla.oms.AdminView.Role.RolesTable;
import com.kaligotla.oms.AdminView.Sponsor.SponsorsTable;
import com.kaligotla.oms.Login;
import com.kaligotla.oms.MainActivity;
import com.kaligotla.oms.R;
import com.kaligotla.oms.OrphanageActivities.AddOrphanageActivities;
import com.kaligotla.oms.orphanage.OrphanagesTable;

public class AdminHome extends AppCompatActivity {
    Spinner menu_spinner;
    String [] menu_array = {"MENU","SPONSORS","CHILDS","ADMINS","ORPHANAGES","ROLES","ADOPTIVE STATUS","LOCATIONS","ADOPT REQUESTS","DONATIONS"};
    Toolbar sponsor_toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_admin_home );
        sponsor_toolbar = findViewById( R.id.sponsor_toolbar );
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,menu_array);
        menu_spinner = findViewById(R.id.menu_spinner);
        menu_spinner.setAdapter(arrayAdapter);
        menu_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    protected void onResume() {
        setSupportActionBar( sponsor_toolbar );
        getSupportActionBar().setDisplayHomeAsUpEnabled( true );
        super.onResume();
    }

    public void sponsors(View view) {
        startActivity( new Intent( AdminHome.this, SponsorsTable.class ) );
    }

    public void admins(View view) {
        startActivity( new Intent( AdminHome.this, AdminsTable.class ) );
    }

    public void childs(View view) {
        startActivity( new Intent( AdminHome.this, ChildsTable.class ) );
    }

    public void orphanages(View view) {
        startActivity( new Intent( AdminHome.this, OrphanagesTable.class ) );
    }

    public void locations(View view) {
        startActivity( new Intent( AdminHome.this, SponsorsTable.class ) );
    }

    public void adoptRequests(View view) {
        startActivity( new Intent( AdminHome.this, SponsorsTable.class ) );
    }

    public void adoptStatus(View view) {
        startActivity( new Intent( AdminHome.this, AdoptiveStatusTable.class ) );
    }

    public void roles(View view) {
        startActivity( new Intent( AdminHome.this, RolesTable.class ) );
    }

    public void donations(View view) {
        startActivity( new Intent( AdminHome.this, SponsorsTable.class ) );
    }

    public void orphanageActivities(View view) {
        startActivity( new Intent( AdminHome.this, SponsorsTable.class ) );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.sponsor_menu, menu );
        menu.removeItem( R.id.login );
        menu.removeItem( R.id.Home );
        menu.removeItem( R.id.donate );
        menu.removeItem( R.id.adopt );
        return super.onCreateOptionsMenu( menu );
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            item.setIcon( R.drawable.back );
            item.setVisible( true );
            finish();
        } else if (item.getTitle().equals( "Home" )) {
            setIntent( new Intent( AdminHome.this, MainActivity.class ) );
        } else if (item.getTitle().equals( "Logout" )) {
            Toast.makeText( this, "Logout", Toast.LENGTH_SHORT ).show();
            SharedPreferences preferences = getSharedPreferences( "store", MODE_PRIVATE );
            preferences.edit().putBoolean( "super_admin_logged_in", false ).commit();
            startActivity( new Intent( AdminHome.this, Login.class ) );
        } else if (item.getTitle().equals("Add")) {
            startActivity( new Intent( this, AddOrphanageActivities.class ) );
        } else {
            finish();
            finish();
            finish();
        }
        return super.onOptionsItemSelected( item );
    }

}