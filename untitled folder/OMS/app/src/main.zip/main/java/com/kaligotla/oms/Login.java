package com.kaligotla.oms;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.kaligotla.oms.AdminView.AdminHome;
import com.kaligotla.oms.Essentials.Constants;
import com.kaligotla.oms.Essentials.DBService;
import com.kaligotla.oms.GuardianView.GuardianHome;
import com.kaligotla.oms.SponsorView.SponsorHome;
import com.kaligotla.oms.VolunteerView.VolunteerHome;

import pl.droidsonroids.gif.GifImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class Login extends AppCompatActivity {
    EditText login_username, login_password;
    CheckBox remember_me;
    GifImageView kids_jumping;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_login );
        login_username = findViewById( R.id.login_username );
        login_password = findViewById( R.id.login_password );
        remember_me = findViewById( R.id.remember_me );
        kids_jumping = findViewById( R.id.kids_jumping );
        SharedPreferences preferences = getSharedPreferences( "sponsor_logged_in", MODE_PRIVATE );
        if (getSharedPreferences( "store", MODE_PRIVATE ).getBoolean( "sponsor_logged_in", false )) {
            Log.e("Sponsor logged in",""+getSharedPreferences( "store", MODE_PRIVATE ).getBoolean( "sponsor_logged_in", false ));
            startActivity( new Intent( Login.this, SponsorHome.class ) );
            finish();
        } else if(getSharedPreferences( "store", MODE_PRIVATE ).getBoolean( "super_admin_logged_in", false )) {
            Log.e("Super Admin logged in",""+getSharedPreferences( "store", MODE_PRIVATE ).getBoolean( "super_admin_logged_in", false ));
            startActivity( new Intent( Login.this, AdminHome.class ) );
            finish();
        } else if(getSharedPreferences( "store", MODE_PRIVATE ).getBoolean( "guardian_logged_in", false )) {
            Log.e("Guardian logged in",""+getSharedPreferences( "store", MODE_PRIVATE ).getBoolean( "guardian_logged_in", false ));
            startActivity( new Intent( Login.this, GuardianHome.class ) );
            finish();
        } else if(getSharedPreferences( "store", MODE_PRIVATE ).getBoolean( "volunteer_logged_in", false )) {
            Log.e("Volunteer logged in",""+getSharedPreferences( "store", MODE_PRIVATE ).getBoolean( "volunteer_logged_in", false ));
            startActivity( new Intent( Login.this, VolunteerHome.class ) );
            finish();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        kids_jumping.animate();
    }

    public void sign_in(View view) {
        Cred cred = validateData();
        if (cred != null) {
            signinSponsor( cred );
        }
    }

    public void signinAdmin(Cred cred) {

        new Retrofit.Builder()
                .addConverterFactory( GsonConverterFactory.create() )
                .baseUrl( Constants.BASE_URL )
                .build()
                .create( DBService.class )
                .adminlogin( cred )
                .enqueue( new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                        JsonArray jsonArray = response.body().getAsJsonArray( "data" );
                        JsonObject jsonObject;
                        Log.e("cred",""+jsonArray);
                        if (jsonArray.size() > 0) {
                            jsonObject = jsonArray.get( 0 ).getAsJsonObject();
                            int admin_id = jsonObject.get( "id" ).getAsInt();
                            String role = jsonObject.get( "role" ).getAsString();
                            saveData( admin_id, role );
                            Toast.makeText( Login.this, "Admin Login successfull", Toast.LENGTH_SHORT ).show();
                            if(role.equals( "Super_Admin" )) {
                                startActivity( new Intent( Login.this, AdminHome.class ) );
                            } else if(role.equals( "Volunteer" )) {
                                startActivity( new Intent( Login.this, VolunteerHome.class ) );
                            } else if(role.equals( "Guardian" )) {
                                startActivity( new Intent( Login.this, GuardianHome.class ) );
                            }
                            finish();
                        }
                        else if(jsonArray.size()==0) {
                            Toast.makeText( Login.this, "You are not either Sponsor Or Admin kindly register as a sponsor", Toast.LENGTH_SHORT ).show();
                        }

                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        Toast.makeText( Login.this, "DB Connection failed", Toast.LENGTH_SHORT ).show();
                    }
                } );
    }

    public void signinSponsor(Cred cred) {
        new Retrofit.Builder()
                .addConverterFactory( GsonConverterFactory.create() )
                .baseUrl( Constants.BASE_URL )
                .build()
                .create( DBService.class )
                .sponsorlogin( cred )
                .enqueue( new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                        JsonArray jsonArray = response.body().getAsJsonArray( "data" );
                        JsonObject jsonObject;
                        Log.e("cred",""+jsonArray);
                        if (jsonArray.size() > 0) {
                            jsonObject = jsonArray.get( 0 ).getAsJsonObject();
                            int sponsor_id = jsonObject.get( "id" ).getAsInt();
                            saveData( sponsor_id, null );
                            Toast.makeText( Login.this, "Sponsor Login successfull", Toast.LENGTH_SHORT ).show();
                            startActivity( new Intent( Login.this, SponsorHome.class ) );
                            finish();
                        }
                        else if(jsonArray.size()==0) {
                            signinAdmin(cred);
                        }

                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        Toast.makeText( Login.this, "DB Connection failed", Toast.LENGTH_SHORT ).show();
                    }
                } );
    }

    public void saveData(int id, String role) {
        SharedPreferences preferences = getSharedPreferences( "store", MODE_PRIVATE );
        preferences.edit().putInt( "sponsor_id", id ).commit();
        preferences.edit().putInt( "admin_id", id ).commit();
        if(remember_me.isChecked()) {
            if(role==null) {
                preferences.edit().putBoolean( "sponsor_logged_in", true ).commit();
            } else if(role.equals( "Volunteer" )) {
                preferences.edit().putBoolean( "volunteer_logged_in", true ).commit();
            } else if(role.equals( "Guardian" )) {
                preferences.edit().putBoolean( "guardian_logged_in", true ).commit();
            } else if(role.equals( "Super_Admin" )) {
                preferences.edit().putBoolean( "super_admin_logged_in", true ).commit();
            }
        }
    }

    public Cred validateData() {
        Cred cred = new Cred();
        cred.setEmail( login_username.getText().toString() );
        cred.setPassword( login_password.getText().toString() );

        if (!cred.getEmail().equals( "" ))
            if (!cred.getPassword().equals( "" ))
                return cred;
            else
                Toast.makeText( this, "Password cannot be empty", Toast.LENGTH_SHORT ).show();
        else
            Toast.makeText( this, "Email cannot be empty", Toast.LENGTH_SHORT ).show();
        return null;
    }

    public void register(View view) {
        startActivity( new Intent( this, Register.class ) );
    }
}